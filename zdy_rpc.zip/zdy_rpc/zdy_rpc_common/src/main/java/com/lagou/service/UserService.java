package com.lagou.service;

public interface UserService {

    public String sayHello(String word);
}
